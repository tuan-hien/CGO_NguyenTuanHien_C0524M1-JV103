package ss_final_test.exception;

public class NotFoundProductException extends Throwable {
    public NotFoundProductException(String message) {
        super(message);
    }
}
